Let me know how you like it and what features you would like in next releases.

FAQ https://mining-bios.eu/guides-and-miners/bios-mod-faqs/

If you need to reset license contact me via e-mail.

>License<
All peformance timings are private.
Sharing this software and timings is not allowed only exceptions are friends and family you can share it with them.
Try to avoid using this SW on more than 3 machines, it won't allow you to use it on more than 3 PCs.

>Anti-Virus<
Source code is blocked from reading by many Anti-viruses so it may be false positive as virus (trojan etc.)
We have fixed many false detection in 2020 August release.
Currently Virustotal only shows 10 Anti-virus detections. We recommend to use ESET.